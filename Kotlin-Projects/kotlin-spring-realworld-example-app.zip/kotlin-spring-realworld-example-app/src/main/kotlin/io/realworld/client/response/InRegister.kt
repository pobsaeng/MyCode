package io.realworld.client.response

import io.realworld.model.inout.Register

data class InRegister(val user: Register)
