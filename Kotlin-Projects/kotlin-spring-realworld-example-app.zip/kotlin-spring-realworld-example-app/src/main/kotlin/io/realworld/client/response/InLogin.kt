package io.realworld.client.response

import io.realworld.model.inout.Login

data class InLogin(val user: Login)
