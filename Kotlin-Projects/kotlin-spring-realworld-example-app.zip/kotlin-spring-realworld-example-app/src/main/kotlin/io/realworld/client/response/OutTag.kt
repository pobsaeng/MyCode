package io.realworld.client.response

data class OutTag(var tags: List<String> = listOf())
