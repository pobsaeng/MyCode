package io.realworld.exception

/**
 * Created by alex on 30/04/2017.
 */
class UserExistException : RuntimeException()