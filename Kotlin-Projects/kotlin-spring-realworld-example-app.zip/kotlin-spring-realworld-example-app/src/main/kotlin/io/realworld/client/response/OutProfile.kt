package io.realworld.client.response

import io.realworld.model.inout.Profile

data class OutProfile(var profile: Profile? = null)
