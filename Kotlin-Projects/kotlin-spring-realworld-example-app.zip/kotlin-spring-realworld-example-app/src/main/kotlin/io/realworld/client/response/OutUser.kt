package io.realworld.client.response

import io.realworld.model.User

data class OutUser(var user: User = User())
