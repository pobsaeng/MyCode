# Kotlin-JWT-Demo

Demo code from "[JSON Web Token Verification in Ktor using Kotlin and Java-JWT](https://www.scottbrady91.com/Kotlin/JSON-Web-Token-Verification-in-Ktor-using-Kotlin-and-Java-JWT)"
