package com.coldstart.Jwt

/**
 * Created by quangio.
 */

data class AccountCredentials(val username: String = "", val password: String = "")