package net.guides.springboot2.springboottestingexamples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTestingExamplesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTestingExamplesApplication.class, args);
	}
}
