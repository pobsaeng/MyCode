package net.javaguides.hibernate.entity;

public enum ProjectStatus {
	OPEN, INPROGESS, RESUME, COMPLETED, CLOSED;
}
