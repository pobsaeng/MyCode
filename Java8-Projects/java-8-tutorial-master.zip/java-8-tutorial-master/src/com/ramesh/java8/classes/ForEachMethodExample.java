package com.ramesh.java8.classes;

public class ForEachMethodExample {

}
